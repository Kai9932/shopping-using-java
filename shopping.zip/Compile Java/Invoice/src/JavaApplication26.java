public class JavaApplication26 {
    
}
