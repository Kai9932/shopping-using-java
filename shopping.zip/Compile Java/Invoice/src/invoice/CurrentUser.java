package invoice;

public class CurrentUser {
    private String userEmail;

    public CurrentUser(String userEmail) {
        this.userEmail = userEmail;
    }

    // Setter method to set user email
    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    // Getter method to get user email
    public String getUserEmail() {
        return userEmail;
    }
}
