
package invoice;
public class Invoice {
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
