/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package invoice;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

/**
 *
 * @author User
 */
public class ManagerDataReader {
    private HashMap<String, String[]> managernData;

    public ManagerDataReader(String filePath) {
        this.managernData = new HashMap<>();
        readManagerData(filePath);
    }

    private void readManagerData(String filePath) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length == 3) {
                    String id = data[0];
                    String email = data[1];
                    String password = data[2];
                    managernData.put(id, new String[]{email, password});
                } else {
                    System.out.println("Invalid data format: " + line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public HashMap<String, String[]> getManagerData() {
        return managernData;
    }
}