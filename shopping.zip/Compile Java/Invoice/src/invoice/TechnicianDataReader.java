package invoice;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

public class TechnicianDataReader {
    private HashMap<String, String[]> technicianData;

    public TechnicianDataReader(String filePath) {
        this.technicianData = new HashMap<>();
        readTechnicianData(filePath);
    }

    private void readTechnicianData(String filePath) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length == 3) {
                    String id = data[0];
                    String email = data[1];
                    String password = data[2];
                    technicianData.put(id, new String[]{email, password});
                } else {
                    System.out.println("Invalid data format: " + line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public HashMap<String, String[]> getTechnicianData() {
        return technicianData;
    }
}
