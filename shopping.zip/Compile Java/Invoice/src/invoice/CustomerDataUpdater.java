package invoice;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

public class CustomerDataUpdater {
    private Map<String, String[]> customerData;

    public CustomerDataUpdater() {
        this.customerData = new HashMap<>();
        readDataFromTXT("Customer.txt");    
    }
    
 public List<String> readCustomerIDsFromTXT(String fileName) {
        List<String> customerIDs = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                customerIDs.add(data[0]); 
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return customerIDs;
    }

    public void readDataFromTXT(String fileName) {
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                String customerId = data[0];
                customerData.put(customerId, data);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void updateCustomerData(String customerId, String orderId, String technician, String serviceType, String brand, String description, String jobStatus) {
        if (customerData.containsKey(customerId)) {
            String[] customerInfo = customerData.get(customerId);
            customerInfo[1] = orderId;
            customerInfo[2] = technician;
            customerInfo[3] = serviceType;
            customerInfo[4] = brand;
            customerInfo[5] = description;
            customerInfo[6] = jobStatus;

            customerData.put(customerId, customerInfo);

            writeDataToTXT("Customer.txt");
        } else {
            System.out.println("Customer ID not found.");
        }
    }

    public void writeDataToTXT(String fileName) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileName))) {
            for (String[] data : customerData.values()) {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < data.length; i++) {
                    sb.append(data[i]);
                    if (i < data.length - 1) {
                        sb.append(",");
                    }
                }
                bw.write(sb.toString());
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
